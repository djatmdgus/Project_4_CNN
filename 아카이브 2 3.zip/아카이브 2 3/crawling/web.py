from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import urllib.request
import os

#query = input('검색어 입력:')
#path = './'
#dir_name = path + query
#os.makedirs(dir_name)
#print(f'[{dir_name} 디렉토리 생성]')


def crawling_img(name):
    driver = webdriver.Chrome('/Users/um_seun/project4/chromedriver') # 크롬드라이버 설치한 경로 작성 필요 
    driver.get("https://www.google.co.kr/imghp?hl=ko&tab=wi&authuser=0&ogbl") # 구글 이미지 검색 url
    elem = driver.find_element_by_name("q") #구글 검색창 선택
    # 검색후 검색어로 디렉토리 생성


    elem.send_keys(name) # 검색창에 검색할 내용(name)넣기
    elem.send_keys(Keys.RETURN) # 검색할 내용을 넣고 enter를 치는것!


    #스크롤 내리기
    last_height = driver.execute_script("return document.body.scrollHeight") # 브라우저의 높이를 자바스크립트로 찾음

    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);") # 브라우저 끝까지 스크롤을 내림
        time.sleep(1)
        new_height = driver.execute_script("return document.body.scrollHeight")

        if last_height == new_height:
            try:
                driver.find_element_by_css_selector(".mye4qd").click() #스크롤을 내리다 보면 "결과 더보기"가 뜨는 경우 이를 클릭해준다
            except:
                break
        last_height = new_height

    img_list = driver.find_elements_by_css_selector(".rg_i.Q4LuWd") # 모든 이미지 리스트로 담기
    count = 1
    for img in img_list:
        try:
            img.click() #이미지 클릭
            time.sleep(1)
            img_src = driver.find_element_by_xpath('//*[@id="Sva75c"]/div/div/div[3]/div[2]/c-wiz/div/div[1]/div[1]/div[3]/div/a/img').get_attribute('src')
            if img_src.split('.')[-1] == 'png':
                urllib.request.urlretrieve(img_src, dir_name + '/' + str(count) + '.png')
                print(f'{count}번째 png 이미지 저장')
                    
            elif img_src.split('.')[-1] == 'jpg':
                urllib.request.urlretrieve(img_src, dir_name + '/' + str(count) + '.jpg')
                print(f'{count}번쨰 jpg 이미지 저장')
                    
            count += 1
            if count >= 100:
                break    
        except:
            pass





#crawling_img(query)

query_s = ['마동석','이병현','공유','고수','류승룡','유아인','강동원','배수지','하지원','한효주','김소은','김태희','송혜교']
for query in query_s:
    path = './'
    dir_name = path + query
    os.makedirs(dir_name)
    print(f'[{dir_name} 디렉토리 생성]')
    crawling_img(query)
